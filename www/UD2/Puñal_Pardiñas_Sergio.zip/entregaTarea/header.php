<header class="bg-primary text-white text-center py-3">
    <h1>Sergio Puñal Pardiñas</h1>
    <h2>A miña aplicación web</h2>
    <h3>Xestión de tarefas</h3>
</header>