<!-- Archivo: footer.php -->
<footer class="bg-dark text-white text-center py-3">
    <p>&copy; 2024 Mi pagína web- Todos los derechos reservados</p>
</footer>
